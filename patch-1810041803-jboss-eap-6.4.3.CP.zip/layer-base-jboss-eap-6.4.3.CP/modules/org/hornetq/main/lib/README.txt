HornetQ Native Module
----------------------
This directory is a placeholder for the Linux native HornetQ module.
To add native functionality to the HornetQ module, add a sub-directory for 
each supported platform.

For example,

./linux-i686/libHornetQAIO32.so
./linux-i86_64/libHornetQAIO64.so

