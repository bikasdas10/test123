JBoss Web Native Module
-----------------------
This directory is a placeholder for the JBoss Web native components.
